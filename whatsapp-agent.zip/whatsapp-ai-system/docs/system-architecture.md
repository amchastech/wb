# System Architecture

## Services
- Frontend Dashboard
- Backend API
- AI Service Layer
- Scheduler Workers
- Media Processing Engine

## Infrastructure
- PostgreSQL
- Redis
- Docker
- Cloudflare CDN
- AWS S3

## AI Flow
Upload Product -> AI Enhancement -> Caption Generation -> Schedule -> Broadcast